// Made by Electus Progressive Liberation Software (EPLS)
// Licensed under the ELECTUS PROGRESSIVE LIBERATION SOFTWARE LICENSE (1.1)


// Instances that dont support embedding
const EMBED_BLOCKLIST = [
    "invidious.nerdvpn.de",
    "inv.nadeko.ygg"
];

const HARD_FALLBACK = ["inv.nadeko.net", "invidious.tiekoetter.com", "yt.chocolatemoo53.com"];

let INSTANCES = [];

let resolveInstancesReady;
let instancesReadyPromise = new Promise((resolve) => { resolveInstancesReady = resolve; });

// The instances list changes depending on the health status of the servers.

// NOTE: Since the service worker can wake up and go to sleep based on events,
// the module-level variables (INSTANCES, instancesReadyPromise) may be reset on each wake-up.
// To handle this, the top-level call at the bottom of this file (fetchOfficialInstanceList())
// automatically refreshes the list on each wake-up.
// Additionally, we write the last known list to chrome.storage.session so that
// the service worker doesn't remain empty, even temporarily, when it restarts.
async function fetchOfficialInstanceList() {
    instancesReadyPromise = new Promise((resolve) => { resolveInstancesReady = resolve; });
    try {
        const cached = await chrome.storage.session.get("instances");
        if (cached.instances && cached.instances.length > 0) {
            INSTANCES = cached.instances;
        }
    } catch (e) {}

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 6000);

        const res = await fetch(
            "https://api.invidious.io/instances.json?sort_by=type,health",
            { signal: controller.signal }
        );
        clearTimeout(timeout);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();

        const liveHosts = data
            .filter(([host, info]) => {
                if (!info || !host) return false;
                if (info.type !== "https") return false; // Only https clearnet servers
                if (EMBED_BLOCKLIST.includes(host.toLowerCase())) return false;
                console.log(`[Bridge-BG] The server on the blocklist has been eliminated: ${host}`);
                return true;
            })
            .map(([host, info]) => {
                const rawUptime = info.monitor?.uptime;
                const health = (rawUptime !== undefined && rawUptime !== null && !isNaN(parseFloat(rawUptime)))
                    ? parseFloat(rawUptime)
                    : null;
                return { host, health };
            })
            .filter(item => item.health === null || item.health >= 80.0)
            .sort((a, b) => {
                if (a.health === null && b.health === null) return 0;
                if (a.health === null) return 1;
                if (b.health === null) return -1;
                return b.health - a.health;
            })
            .map(item => item.host);

        INSTANCES = liveHosts.length > 0 ? liveHosts : HARD_FALLBACK;
        console.log("[Bridge-BG/Chrome] Instance list (sorted by health):", INSTANCES);
    } catch (err) {
        console.warn("[Bridge-BG/Chrome] Could not retrieve API list, fallback is being used:", err);
        if (INSTANCES.length === 0) INSTANCES = HARD_FALLBACK;
    }

    try {
        await chrome.storage.session.set({ instances: INSTANCES });
    } catch (e) {}

    resolveInstancesReady();
}

fetchOfficialInstanceList();

async function injectIntoExistingTabs() {
    try {
        const tabs = await chrome.tabs.query({ url: "*://*.youtube.com/watch*" });
        for (const tab of tabs) {
            try {
                await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ["content.js"]
                });
                console.log(`[Bridge-BG/Chrome] content.js mevcut sekmeye enjekte edildi (tab ${tab.id}).`);
            } catch (err) {
                console.warn(`[Bridge-BG/Chrome] Sekmeye enjekte edilemedi (tab ${tab.id}):`, err);
            }
        }
    } catch (err) {
        console.warn("[Bridge-BG/Chrome] Mevcut sekmeler taranamadı:", err);
    }
}

injectIntoExistingTabs();

chrome.runtime.onInstalled.addListener(() => {
    injectIntoExistingTabs();
});

if (chrome.runtime.onStartup) {
    chrome.runtime.onStartup.addListener(() => {
        injectIntoExistingTabs();
    });
}

let resolveCspReady;
const cspReadyPromise = new Promise((resolve) => { resolveCspReady = resolve; });

// CSP Mitigation (declarativeNetRequest, static rule)
async function ensureCspRule() {
    const RULE_ID = 1;
    try {
        await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [RULE_ID],
            addRules: [
                {
                    id: RULE_ID,
                    priority: 1,
                    action: {
                        type: "modifyHeaders",
                        responseHeaders: [
                            { header: "content-security-policy", operation: "remove" },
                            { header: "content-security-policy-report-only", operation: "remove" }
                        ]
                    },
                    condition: {
                        requestDomains: ["youtube.com"],
                        resourceTypes: ["main_frame", "sub_frame"]
                    }
                }
            ]
        });
        console.log("[Bridge-BG/Chrome] The CSP removal rule (declarativeNetRequest) is registered.");
    } catch (err) {
        console.warn("[Bridge-BG/Chrome] CSP rule could not be registered:", err);
    }
    resolveCspReady();
}
ensureCspRule();

function isTrackedInstanceHost(host) {
    return INSTANCES.includes(host);
}

function parseSetCookie(rawValue) {
    const parts = rawValue.split(';').map(p => p.trim());
    const eqIdx = parts[0].indexOf('=');
    if (eqIdx === -1) return null;

    const name = parts[0].slice(0, eqIdx);
    const value = parts[0].slice(eqIdx + 1);

    let path = "/";
    let expirationDate;

    for (const part of parts.slice(1)) {
        const eq = part.indexOf('=');
        const key = (eq === -1 ? part : part.slice(0, eq)).toLowerCase();
        const val = eq === -1 ? "" : part.slice(eq + 1);

        if (key === "path") path = val || "/";
        if (key === "expires") {
            const ms = Date.parse(val);
            if (!isNaN(ms)) expirationDate = ms / 1000;
        }
        if (key === "max-age") {
            const seconds = parseInt(val, 10);
            if (!isNaN(seconds)) expirationDate = Date.now() / 1000 + seconds;
        }
    }

    return { name, value, path, expirationDate };
}

if (chrome.webRequest && chrome.cookies) {
    chrome.webRequest.onHeadersReceived.addListener(
        (details) => {
            let host;
            try { host = new URL(details.url).host; } catch (e) { return; }
            if (!isTrackedInstanceHost(host)) return;
            if (!details.responseHeaders) return;

            const setCookieHeaders = details.responseHeaders.filter(
                h => h.name.toLowerCase() === "set-cookie"
            );
            if (setCookieHeaders.length === 0) return;

            for (const header of setCookieHeaders) {
                const cookie = parseSetCookie(header.value);
                if (!cookie) continue;

                chrome.cookies.set({
                    url: `https://${host}${cookie.path}`,
                    name: cookie.name,
                    value: cookie.value,
                    path: cookie.path,
                    secure: true,
                    sameSite: "no_restriction", // SameSite=None
                    expirationDate: cookie.expirationDate
                }).then(() => {
                    console.log(`[Bridge-BG/Chrome] The cookie ${cookie.name} was rewritten to SameSite=None (${host}).`);
                }).catch((err) => {
                    console.warn(`[Bridge-BG/Chrome] The cookie could not be corrected. (${host}):`, err);
                });
            }
        },
        { urls: ["<all_urls>"] },
        ["responseHeaders", "extraHeaders"]
    );
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === "getInstances") {
        Promise.all([instancesReadyPromise, cspReadyPromise]).then(() => {
            sendResponse({ instances: INSTANCES });
        });
        return true;
    }
    if (message.action === "checkVideoExists") {
        checkVideoExists(message.host, message.videoId).then(sendResponse);
        return true;
    }
});

async function checkVideoExists(host, videoId) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    try {
        const res = await fetch(`https://${host}/api/v1/videos/${videoId}`, { signal: controller.signal });
        clearTimeout(timeout);
        if (res.status === 404) return false;
        if (!res.ok) return null;
        const data = await res.json();
        if (data && data.error) return false;
        return true;
    } catch (err) {
        clearTimeout(timeout);
        return null;
    }
}
