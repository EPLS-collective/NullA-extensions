// Made by Electus Progressive Liberation Software (EPLS)
// Licensed under the ELECTUS PROGRESSIVE LIBERATION SOFTWARE LICENSE (1.1)

(function () {
    'use strict';

    if (window.__inviBridgeLoaded) return;
    window.__inviBridgeLoaded = true;

    console.log('[Bridge-UI] content.js loaded. URL:', window.location.href);

    const browserAPI = (typeof browser !== 'undefined') ? browser : chrome;

    let INSTANCES = [];
    let currentVideoId = "";
    let isProcessing = false;

    function getVideoId() {
        return new URLSearchParams(window.location.search).get('v');
    }

    function fetchInstanceList() {
        return new Promise((resolve) => {
            browserAPI.runtime.sendMessage({ action: "getInstances" }, function(response) {
                if (browserAPI.runtime.lastError || !response || !response.instances || response.instances.length === 0) {
                    console.warn('[Bridge-UI] Could not retrieve dynamic list from Background.');
                    resolve([]);
                    return;
                }
                INSTANCES = response.instances;
                resolve(INSTANCES);
            });
        });
    }

    function silenceNativePlayer(ytPlayer) {
        if (!ytPlayer) return;
        try { ytPlayer.pauseVideo?.(); } catch (e) {}
        try { ytPlayer.mute?.(); } catch (e) {}

        const video = ytPlayer.querySelector?.('video');
        if (video) {
            try {
                video.pause();
                video.muted = true;
                video.volume = 0;
            } catch (e) {}

            if (!video.dataset.bridgeSilenced) {
                video.dataset.bridgeSilenced = "true";
                video.addEventListener('play', () => video.pause());
                video.addEventListener('playing', () => video.pause());
                video.addEventListener('volumechange', () => {
                    if (!video.muted || video.volume > 0) {
                        video.muted = true;
                        video.volume = 0;
                    }
                });
            }
        }

        ytPlayer.style.setProperty('visibility', 'hidden', 'important');
        ytPlayer.style.setProperty('pointer-events', 'none', 'important');
    }

    setInterval(() => {
        const yt = document.querySelector('#movie_player, ytd-player');
        if (yt) silenceNativePlayer(yt);
    }, 1000);

        function showStatus(wrapper, text) {
            let status = wrapper.querySelector('.bridge-status');
            if (!status) {
                status = document.createElement('div');
                status.className = 'bridge-status';
                status.style.cssText = `
                position: absolute; top: 50%; left: 50%;
                transform: translate(-50%, -50%);
                color: #fff; font-family: sans-serif; font-size: 14px;
                z-index: 5; text-align: center; pointer-events: none;
                `;
                wrapper.appendChild(status);
            }
            status.textContent = text;
        }

        let activeTryIndex = -1;
        let activeTryList = [];

        function ensureSkipButton(wrapper) {
            let btn = wrapper.querySelector('.bridge-skip-btn');
            if (btn) return btn;

            btn = document.createElement('button');
            btn.className = 'bridge-skip-btn';
            btn.textContent = 'Try a different mirror';
            btn.style.cssText = `
            position: absolute; top: 12px; right: 12px;
            z-index: 2147483647;
            background: rgba(0,0,0,0.85); color: #fff;
            border: 1px solid rgba(255,255,255,0.4); border-radius: 6px;
            padding: 8px 12px; font-family: sans-serif; font-size: 12px;
            cursor: pointer; pointer-events: none;
            opacity: 0; transition: opacity 0.25s ease;
            `;
            btn.addEventListener('click', () => {
                const videoId = getVideoId();
                if (!videoId || videoId !== currentVideoId) return;
                console.log('[Bridge-UI] Switching to the next healthy server.');
                tryInstances(wrapper, videoId, activeTryIndex + 1, activeTryList);
            });
            wrapper.appendChild(btn);

            setupAutoHide(wrapper, btn);
            return btn;
        }

        function setupAutoHide(wrapper, btn) {
            if (wrapper.dataset.autoHideBound) return;
            wrapper.dataset.autoHideBound = "true";

            let hideTimer = null;

            function revealButton() {
                btn.style.opacity = '1';
                btn.style.pointerEvents = 'auto';
                clearTimeout(hideTimer);
                hideTimer = setTimeout(() => {
                    btn.style.opacity = '0';
                    btn.style.pointerEvents = 'none';
                }, 2500);
            }

            wrapper.addEventListener('mousemove', revealButton);
            wrapper.addEventListener('mouseenter', revealButton);
            wrapper.addEventListener('mouseleave', () => {
                clearTimeout(hideTimer);
                btn.style.opacity = '0';
                btn.style.pointerEvents = 'none';
            });

            revealButton();
        }

        function solveChallenge(host, videoId, onDone) {
            const probe = document.createElement('iframe');
            probe.style.cssText = 'position:absolute; width:1px; height:1px; opacity:0; pointer-events:none; left:-9999px;';

            let settled = false;
            let loadCount = 0;
            const maxLoads = 6;
            const hardTimeout = setTimeout(() => finish(false), 15000);

            function finish(success) {
                if (settled) return;
                settled = true;
                clearTimeout(hardTimeout);
                probe.remove();
                onDone(success);
            }

            probe.addEventListener('load', () => {
                loadCount++;
                let currentUrl;
                try {
                    currentUrl = probe.contentWindow.location.href;
                } catch (e) {}

                const stillChallenging = currentUrl && (currentUrl.includes('__goaway_challenge') || currentUrl.includes('go-away'));

                if (!stillChallenging && loadCount > 0) {
                    finish(true);
                    return;
                }

                if (loadCount >= maxLoads) {
                    finish(false);
                }
            });

            probe.src = `https://${host}/embed/${videoId}?autoplay=1`;
            document.body.appendChild(probe);
            return probe;
        }

        function tryInstances(wrapper, videoId, index, list) {
            if (videoId !== currentVideoId) return;
            if (!document.body.contains(wrapper)) return;

            activeTryIndex = index;
            activeTryList = list;

            if (index >= list.length) {
                showStatus(wrapper, 'This video could not be found on any of the servers in the active list.');
                return;
            }

            const host = list[index];
            showStatus(wrapper, `Querying video on server ${host}...`);
            ensureSkipButton(wrapper);

            browserAPI.runtime.sendMessage(
                { action: "checkVideoExists", host: host, videoId: videoId },
                function (exists) {
                    if (videoId !== currentVideoId || !document.body.contains(wrapper)) return;

                    if (exists === false) {
                        console.log(`[Bridge-UI] This video does not exist on server ${host} (404). Skipping to the next one...`);
                        tryInstances(wrapper, videoId, index + 1, list);
                        return;
                    }

                    showStatus(wrapper, `Connecting to ${host} (resolving bot control)...`);
                    solveChallenge(host, videoId, (success) => {
                        if (videoId !== currentVideoId || !document.body.contains(wrapper)) return;

                        if (success) {
                            console.log(`[Bridge-UI] Found running server: ${host}`);
                            injectIframe(wrapper, host, videoId);
                        } else {
                            console.warn(`[Bridge-UI] ${host} failed, moving to the next one in the list...`);
                            tryInstances(wrapper, videoId, index + 1, list);
                        }
                    });
                }
            );
        }

        function injectIframe(wrapper, host, videoId) {
            const existingProbe = wrapper.querySelector('iframe');
            if (existingProbe) existingProbe.remove();

            const iframe = document.createElement('iframe');
            iframe.src = `https://${host}/embed/${videoId}?autoplay=1`;

            const isFullscreen = !!(document.fullscreenElement || document.webkitFullscreenElement);
            const radiusVal = isFullscreen ? '0px' : '12px';

            Object.assign(iframe.style, {
                width: '100%',
                height: '100%',
                border: 'none',
                position: 'relative',
                zIndex: '2',
                borderRadius: radiusVal,
                transition: 'border-radius 0.15s ease'
            });
            iframe.allow = 'autoplay; fullscreen; encrypted-media; picture-in-picture';

            iframe.addEventListener('load', () => {
                const status = wrapper.querySelector('.bridge-status');
                if (status) status.remove();
            });

                wrapper.appendChild(iframe);
                ensureSkipButton(wrapper);
                console.log(`[Bridge-UI] Iframe yüklendi: ${host}`);
        }

        let lastKnownParent = null;

        function cleanupPlayer() {
            const wrapper = document.getElementById('invidious-wrapper');
            if (wrapper) {
                wrapper.remove();
                console.log('[Bridge-UI] Player cleaned.');
            }
            currentVideoId = "";
            isProcessing = false;
        }

        function injectPlayer() {
            const videoId = getVideoId();
            if (!videoId) {
                cleanupPlayer();
                return;
            }

            if (isProcessing) return;

            const existingWrapper = document.getElementById('invidious-wrapper');
            if (videoId === currentVideoId && existingWrapper) return;

            if (existingWrapper) {
                lastKnownParent = existingWrapper.parentElement;
                existingWrapper.remove();
            }

            let parent = null;
            const ytPlayer = document.querySelector('#movie_player, ytd-player');

            if (ytPlayer) {
                parent = ytPlayer.parentElement;
                silenceNativePlayer(ytPlayer);
            } else if (lastKnownParent && document.body.contains(lastKnownParent)) {
                parent = lastKnownParent;
            } else {
                if (videoId !== currentVideoId) {
                    setTimeout(injectPlayer, 300);
                }
                return;
            }

            isProcessing = true;
            currentVideoId = videoId;

            if (getComputedStyle(parent).position === 'static') {
                parent.style.position = 'relative';
            }

            const wrapper = document.createElement('div');
            wrapper.id = 'invidious-wrapper';

            const isFullscreen = !!(document.fullscreenElement || document.webkitFullscreenElement);
            const radiusVal = isFullscreen ? '0px' : '12px';
            const overflowVal = isFullscreen ? 'visible' : 'hidden';

            Object.assign(wrapper.style, {
                position: 'absolute',
                inset: '0',
                width: '100%',
                height: '100%',
                backgroundColor: '#000',
                zIndex: '2147483647',
                borderRadius: radiusVal,
                overflow: overflowVal,
                transition: 'border-radius 0.15s ease'
            });

            parent.appendChild(wrapper);
            lastKnownParent = parent;

            showStatus(wrapper, 'Server list is retrieved from API... (api.invidious.io)');

            fetchInstanceList().then((list) => {
                tryInstances(wrapper, videoId, 0, list);
                isProcessing = false;
            });
        }

        function handleFullscreenChange() {
            const wrapper = document.getElementById('invidious-wrapper');
            if (!wrapper) return;

            const iframe = wrapper.querySelector('iframe');
            const isFullscreen = !!(document.fullscreenElement || document.webkitFullscreenElement);

            if (isFullscreen) {
                console.log('[Bridge-UI] Switched to full screen.');
                wrapper.style.borderRadius = '0px';
                wrapper.style.overflow = 'visible';
                if (iframe) {
                    iframe.style.borderRadius = '0px';
                }
            } else {
                console.log('[Bridge-UI] Screen minimized');
                wrapper.style.borderRadius = '12px';
                wrapper.style.overflow = 'hidden';
                if (iframe) {
                    iframe.style.borderRadius = '12px';
                }
            }
        }

        document.addEventListener('fullscreenchange', handleFullscreenChange);
        document.addEventListener('webkitfullscreenchange', handleFullscreenChange);

        setInterval(() => {
            const videoId = getVideoId();
            if (videoId !== currentVideoId) {
                injectPlayer();
            }
        }, 800);

        let mutationDebounce = null;
        const observer = new MutationObserver(() => {
            clearTimeout(mutationDebounce);
            mutationDebounce = setTimeout(injectPlayer, 150);
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        window.addEventListener('yt-navigate-finish', () => {
            injectPlayer();
        });

        injectPlayer();
})();
